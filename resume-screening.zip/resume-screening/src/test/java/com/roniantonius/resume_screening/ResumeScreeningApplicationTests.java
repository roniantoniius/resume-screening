package com.roniantonius.resume_screening;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeScreeningApplicationTests {

	@Test
	void contextLoads() {
	}

}

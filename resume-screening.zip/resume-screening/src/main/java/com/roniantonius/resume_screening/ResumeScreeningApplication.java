package com.roniantonius.resume_screening;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeScreeningApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumeScreeningApplication.class, args);
	}

}
